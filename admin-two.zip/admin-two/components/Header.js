/**
 * Header Component - Admin Panel
 * Componente modular con soporte para parámetros dinámicos
 * @module Header
 */

const Header = {
    // Configuración por defecto
    defaultConfig: {
        logo: {
            icon: '../../assets/img/gourmet-logo-icon.png',
            text: 'Admin Panel',
            showIcon: true
        },
        user: {
            name: 'Administrador',
            avatar: null,
            role: 'Admin'
        },
        notifications: {
            count: 0,
            items: []
        },
        search: {
            enabled: true,
            placeholder: 'Buscar...'
        },
        theme: {
            mode: 'light' // 'light' | 'dark'
        },
        actions: []
    },

    // Estado interno
    state: {
        isSearchOpen: false,
        isProfileMenuOpen: false,
        isNotificationsOpen: false,
        isMobileMenuOpen: false
    },

    /**
     * Inicializa el componente Header
     * @param {string} containerId - ID del contenedor donde se renderizará
     * @param {Object} config - Configuración personalizada
     */
    init(containerId, config = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`Header: Contenedor #${containerId} no encontrado`);
            return;
        }

        // Fusionar configuración
        this.config = this.mergeConfig(this.defaultConfig, config);

        // Cargar CSS
        this.loadStyles();

        // Renderizar
        this.render();

        // Inicializar eventos
        this.bindEvents();
    },

    /**
     * Fusiona la configuración por defecto con la personalizada
     */
    mergeConfig(defaults, custom) {
        const merged = { ...defaults };
        Object.keys(custom).forEach(key => {
            if (typeof custom[key] === 'object' && !Array.isArray(custom[key]) && custom[key] !== null) {
                merged[key] = { ...defaults[key], ...custom[key] };
            } else {
                merged[key] = custom[key];
            }
        });
        return merged;
    },

    /**
     * Carga los estilos CSS del componente
     */
    loadStyles() {
        if (!document.getElementById('header-styles')) {
            const link = document.createElement('link');
            link.id = 'header-styles';
            link.rel = 'stylesheet';
            link.href = '../../assets/header.css';
            document.head.appendChild(link);
        }
    },

    /**
     * Genera el HTML del componente
     */
    render() {
        const { logo, user, notifications, search, theme, actions } = this.config;

        const html = `
            <header class="admin-header" data-theme="${theme.mode}">
                <div class="header__container">
                    <!-- Left Section: Logo & Mobile Toggle -->
                    <div class="header__left">
                        <button class="header__mobile-toggle" id="header-mobile-toggle" aria-label="Toggle menu">
                            <span class="hamburger-line"></span>
                            <span class="hamburger-line"></span>
                            <span class="hamburger-line"></span>
                        </button>
                        
                        <a href="../../app/dashboard/" class="header__logo">
                            ${logo.showIcon ? `<img src="${logo.icon}" alt="Logo" class="header__logo-icon">` : ''}
                            <span class="header__logo-text">${logo.text}</span>
                        </a>
                    </div>

                    <!-- Center Section: Search -->
                    ${search.enabled ? `
                    <div class="header__center">
                        <div class="header__search" id="header-search">
                            <i class="fa-solid fa-magnifying-glass header__search-icon"></i>
                            <input 
                                type="search" 
                                class="header__search-input" 
                                placeholder="${search.placeholder}"
                                id="header-search-input"
                            >
                            <button class="header__search-clear" id="header-search-clear">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                    </div>
                    ` : ''}

                    <!-- Right Section: Actions & User -->
                    <div class="header__right">
                        <!-- Theme Toggle -->
                        <button class="header__action-btn" id="theme-toggle" title="Cambiar tema">
                            <i class="fa-solid fa-moon" id="theme-icon"></i>
                        </button>

                        <!-- Notifications -->
                        <div class="header__dropdown" id="notifications-dropdown">
                            <button class="header__action-btn header__notifications-btn" id="notifications-toggle">
                                <i class="fa-solid fa-bell"></i>
                                ${notifications.count > 0 ? `<span class="header__badge">${notifications.count}</span>` : ''}
                            </button>
                            <div class="header__dropdown-menu header__notifications-menu">
                                <div class="header__dropdown-header">
                                    <h4>Notificaciones</h4>
                                    <button class="header__dropdown-action">Marcar todo leído</button>
                                </div>
                                <div class="header__notifications-list" id="notifications-list">
                                    ${this.renderNotifications(notifications.items)}
                                </div>
                            </div>
                        </div>

                        <!-- Custom Actions -->
                        ${actions.map(action => `
                            <button class="header__action-btn" title="${action.title}" data-action="${action.id}">
                                <i class="${action.icon}"></i>
                            </button>
                        `).join('')}

                        <!-- User Profile -->
                        <div class="header__dropdown header__profile" id="profile-dropdown">
                            <button class="header__profile-btn" id="profile-toggle">
                                <div class="header__avatar">
                                    ${user.avatar
                ? `<img src="${user.avatar}" alt="${user.name}">`
                : `<span class="header__avatar-initials">${this.getInitials(user.name)}</span>`
            }
                                </div>
                                <div class="header__user-info">
                                    <span class="header__user-name">${user.name}</span>
                                    <span class="header__user-role">${user.role}</span>
                                </div>
                                <i class="fa-solid fa-chevron-down header__profile-arrow"></i>
                            </button>
                            <div class="header__dropdown-menu header__profile-menu">
                                <a href="../../app/profile/" class="header__menu-item">
                                    <i class="fa-solid fa-user"></i>
                                    <span>Mi Perfil</span>
                                </a>
                                <a href="../../app/settings/" class="header__menu-item">
                                    <i class="fa-solid fa-gear"></i>
                                    <span>Configuración</span>
                                </a>
                                <div class="header__menu-divider"></div>
                                <button class="header__menu-item header__menu-item--danger" id="logout-btn">
                                    <i class="fa-solid fa-right-from-bracket"></i>
                                    <span>Cerrar Sesión</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        `;

        this.container.innerHTML = html;
    },

    /**
     * Renderiza las notificaciones
     */
    renderNotifications(items) {
        if (!items || items.length === 0) {
            return `
                <div class="header__empty-state">
                    <i class="fa-regular fa-bell-slash"></i>
                    <p>No hay notificaciones</p>
                </div>
            `;
        }

        return items.map(item => `
            <div class="header__notification-item ${item.read ? '' : 'header__notification-item--unread'}">
                <div class="header__notification-icon" style="background: ${item.color || 'var(--admin-primary)'}">
                    <i class="${item.icon || 'fa-solid fa-info'}"></i>
                </div>
                <div class="header__notification-content">
                    <p class="header__notification-text">${item.text}</p>
                    <span class="header__notification-time">${item.time}</span>
                </div>
            </div>
        `).join('');
    },

    /**
     * Obtiene las iniciales del nombre
     */
    getInitials(name) {
        return name
            .split(' ')
            .map(word => word.charAt(0))
            .join('')
            .toUpperCase()
            .slice(0, 2);
    },

    /**
     * Vincula los eventos del componente
     */
    bindEvents() {
        // Mobile toggle
        const mobileToggle = document.getElementById('header-mobile-toggle');
        if (mobileToggle) {
            mobileToggle.addEventListener('click', () => this.toggleMobileMenu());
        }

        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Search
        const searchInput = document.getElementById('header-search-input');
        const searchClear = document.getElementById('header-search-clear');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.handleSearch(e));
            searchInput.addEventListener('focus', () => this.handleSearchFocus());
        }
        if (searchClear) {
            searchClear.addEventListener('click', () => this.clearSearch());
        }

        // Dropdowns
        this.initDropdowns();

        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        // Close dropdowns on outside click
        document.addEventListener('click', (e) => this.handleOutsideClick(e));

        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    },

    /**
     * Inicializa los dropdowns
     */
    initDropdowns() {
        const dropdowns = ['notifications', 'profile'];

        dropdowns.forEach(name => {
            const toggle = document.getElementById(`${name}-toggle`);
            const dropdown = document.getElementById(`${name}-dropdown`);

            if (toggle && dropdown) {
                toggle.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.toggleDropdown(dropdown);
                });
            }
        });
    },

    /**
     * Toggle dropdown
     */
    toggleDropdown(dropdown) {
        const isOpen = dropdown.classList.contains('is-open');

        // Close all dropdowns first
        document.querySelectorAll('.header__dropdown').forEach(d => {
            d.classList.remove('is-open');
        });

        // Toggle current
        if (!isOpen) {
            dropdown.classList.add('is-open');
        }
    },

    /**
     * Toggle mobile menu
     */
    toggleMobileMenu() {
        this.state.isMobileMenuOpen = !this.state.isMobileMenuOpen;
        const toggle = document.getElementById('header-mobile-toggle');

        if (toggle) {
            toggle.classList.toggle('is-open', this.state.isMobileMenuOpen);
        }

        // Dispatch event for sidebar
        window.dispatchEvent(new CustomEvent('header:toggleMobile', {
            detail: { isOpen: this.state.isMobileMenuOpen }
        }));
    },

    /**
     * Toggle theme
     */
    toggleTheme() {
        const header = document.querySelector('.admin-header');
        const icon = document.getElementById('theme-icon');

        const currentTheme = header.dataset.theme;
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';

        header.dataset.theme = newTheme;
        this.config.theme.mode = newTheme;

        if (icon) {
            icon.className = newTheme === 'light' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
        }

        // Dispatch event for global theme change
        window.dispatchEvent(new CustomEvent('theme:change', {
            detail: { theme: newTheme }
        }));

        // Save preference
        localStorage.setItem('admin-theme', newTheme);
    },

    /**
     * Handle search input
     */
    handleSearch(e) {
        const value = e.target.value;
        const searchContainer = document.getElementById('header-search');
        const clearBtn = document.getElementById('header-search-clear');

        if (searchContainer) {
            searchContainer.classList.toggle('has-value', value.length > 0);
        }
        if (clearBtn) {
            clearBtn.style.display = value.length > 0 ? 'flex' : 'none';
        }

        // Dispatch search event
        window.dispatchEvent(new CustomEvent('header:search', {
            detail: { query: value }
        }));
    },

    handleSearchFocus() {
        const searchContainer = document.getElementById('header-search');
        if (searchContainer) {
            searchContainer.classList.add('is-focused');
        }
    },

    clearSearch() {
        const input = document.getElementById('header-search-input');
        const searchContainer = document.getElementById('header-search');

        if (input) {
            input.value = '';
            input.focus();
        }
        if (searchContainer) {
            searchContainer.classList.remove('has-value');
        }

        window.dispatchEvent(new CustomEvent('header:search', {
            detail: { query: '' }
        }));
    },

    /**
     * Handle outside click
     */
    handleOutsideClick(e) {
        // Close dropdowns
        if (!e.target.closest('.header__dropdown')) {
            document.querySelectorAll('.header__dropdown').forEach(d => {
                d.classList.remove('is-open');
            });
        }

        // Close search focus
        if (!e.target.closest('.header__search')) {
            const searchContainer = document.getElementById('header-search');
            if (searchContainer) {
                searchContainer.classList.remove('is-focused');
            }
        }
    },

    /**
     * Handle keyboard navigation
     */
    handleKeyboard(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.header__dropdown').forEach(d => {
                d.classList.remove('is-open');
            });
        }

        // Ctrl/Cmd + K for search focus
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            const searchInput = document.getElementById('header-search-input');
            if (searchInput) {
                searchInput.focus();
            }
        }
    },

    /**
     * Handle logout
     */
    handleLogout() {
        window.dispatchEvent(new CustomEvent('header:logout'));
        // Default behavior - can be overridden
        localStorage.removeItem('admin-user');
        window.location.href = '../../login.html';
    },

    /**
     * Update notifications
     * @param {Array} items - New notification items
     */
    updateNotifications(items) {
        this.config.notifications.items = items;
        this.config.notifications.count = items.filter(i => !i.read).length;

        const list = document.getElementById('notifications-list');
        const badge = document.querySelector('.header__badge');

        if (list) {
            list.innerHTML = this.renderNotifications(items);
        }

        if (badge) {
            badge.textContent = this.config.notifications.count;
            badge.style.display = this.config.notifications.count > 0 ? 'flex' : 'none';
        }
    },

    /**
     * Update user info
     * @param {Object} user - User data
     */
    updateUser(user) {
        this.config.user = { ...this.config.user, ...user };

        const userName = document.querySelector('.header__user-name');
        const userRole = document.querySelector('.header__user-role');
        const avatar = document.querySelector('.header__avatar');

        if (userName) userName.textContent = user.name;
        if (userRole) userRole.textContent = user.role;
        if (avatar && user.avatar) {
            avatar.innerHTML = `<img src="${user.avatar}" alt="${user.name}">`;
        } else if (avatar) {
            avatar.innerHTML = `<span class="header__avatar-initials">${this.getInitials(user.name)}</span>`;
        }
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Header;
}
