/**
 * SideBar Component - Admin Panel
 * Componente modular con soporte para navegación dinámica
 * @module SideBar
 */

const SideBar = {
    // Configuración por defecto
    defaultConfig: {
        brand: {
            icon: '../../assets/img/gourmet-logo-icon.png',
            name: 'Gourmet Admin',
            tagline: 'Panel de Control'
        },
        navigation: [
            {
                id: 'dashboard',
                label: 'Dashboard',
                icon: 'fa-solid fa-grid-2',
                href: '../../app/dashboard/',
                badge: null
            },
            {
                id: 'products',
                label: 'Productos',
                icon: 'fa-solid fa-box',
                href: '../../app/products/',
                badge: null,
                children: [
                    { id: 'all-products', label: 'Todos', href: '../../app/products/' },
                    { id: 'add-product', label: 'Añadir Nuevo', href: '../../app/products/add.html' },
                    { id: 'categories', label: 'Categorías', href: '../../app/products/categories.html' }
                ]
            },
            {
                id: 'orders',
                label: 'Pedidos',
                icon: 'fa-solid fa-shopping-cart',
                href: '../../app/orders/',
                badge: { count: 5, type: 'warning' }
            },
            {
                id: 'customers',
                label: 'Clientes',
                icon: 'fa-solid fa-users',
                href: '../../app/customers/',
                badge: null
            },
            {
                id: 'analytics',
                label: 'Analíticas',
                icon: 'fa-solid fa-chart-line',
                href: '../../app/analytics/',
                badge: null
            },
            {
                id: 'settings',
                label: 'Configuración',
                icon: 'fa-solid fa-gear',
                href: '../../app/settings/',
                badge: null
            }
        ],
        quickActions: [
            {
                id: 'new-product',
                label: 'Nuevo Producto',
                icon: 'fa-solid fa-plus',
                action: 'addProduct'
            },
            {
                id: 'new-order',
                label: 'Nuevo Pedido',
                icon: 'fa-solid fa-cart-plus',
                action: 'addOrder'
            }
        ],
        footer: {
            showHelp: true,
            helpText: '¿Necesitas ayuda?',
            helpLink: '../../app/support/'
        },
        collapsed: false,
        activeItem: null // Se detecta automáticamente por URL
    },

    // Estado interno
    state: {
        isCollapsed: false,
        isMobileOpen: false,
        expandedMenus: [],
        activeItem: null
    },

    /**
     * Inicializa el componente SideBar
     * @param {string} containerId - ID del contenedor donde se renderizará
     * @param {Object} config - Configuración personalizada
     */
    init(containerId, config = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`SideBar: Contenedor #${containerId} no encontrado`);
            return;
        }

        // Fusionar configuración
        this.config = this.mergeConfig(this.defaultConfig, config);

        // Detectar item activo por URL
        this.detectActiveItem();

        // Restaurar estado desde localStorage
        this.restoreState();

        // Cargar CSS
        this.loadStyles();

        // Renderizar
        this.render();

        // Inicializar eventos
        this.bindEvents();
    },

    /**
     * Fusiona la configuración
     */
    mergeConfig(defaults, custom) {
        const merged = { ...defaults };
        Object.keys(custom).forEach(key => {
            if (Array.isArray(custom[key])) {
                merged[key] = custom[key];
            } else if (typeof custom[key] === 'object' && custom[key] !== null) {
                merged[key] = { ...defaults[key], ...custom[key] };
            } else {
                merged[key] = custom[key];
            }
        });
        return merged;
    },

    /**
     * Detecta el item activo basado en la URL actual
     */
    detectActiveItem() {
        const currentPath = window.location.pathname;

        const findActive = (items) => {
            for (const item of items) {
                if (item.href && currentPath.includes(item.href.replace('../../', ''))) {
                    return item.id;
                }
                if (item.children) {
                    const childActive = findActive(item.children);
                    if (childActive) {
                        this.state.expandedMenus.push(item.id);
                        return childActive;
                    }
                }
            }
            return null;
        };

        this.state.activeItem = this.config.activeItem || findActive(this.config.navigation);
    },

    /**
     * Restaura el estado desde localStorage
     */
    restoreState() {
        const savedCollapsed = localStorage.getItem('sidebar-collapsed');
        if (savedCollapsed !== null) {
            this.state.isCollapsed = savedCollapsed === 'true';
        }
    },

    /**
     * Carga los estilos CSS
     */
    loadStyles() {
        if (!document.getElementById('sidebar-styles')) {
            const link = document.createElement('link');
            link.id = 'sidebar-styles';
            link.rel = 'stylesheet';
            link.href = '../../assets/sidebar.css';
            document.head.appendChild(link);
        }
    },

    /**
     * Genera el HTML del componente
     */
    render() {
        const { brand, navigation, quickActions, footer } = this.config;

        const html = `
            <aside class="admin-sidebar ${this.state.isCollapsed ? 'is-collapsed' : ''}" id="admin-sidebar">
                <!-- Overlay for mobile -->
                <div class="sidebar__overlay" id="sidebar-overlay"></div>
                
                <div class="sidebar__container">
                    <!-- Header / Brand -->
                    <div class="sidebar__header">
                        <a href="../../app/dashboard/" class="sidebar__brand">
                            <img src="${brand.icon}" alt="${brand.name}" class="sidebar__brand-icon">
                            <div class="sidebar__brand-info">
                                <span class="sidebar__brand-name">${brand.name}</span>
                                <span class="sidebar__brand-tagline">${brand.tagline}</span>
                            </div>
                        </a>
                        <button class="sidebar__collapse-btn" id="sidebar-collapse" title="Colapsar menú">
                            <i class="fa-solid fa-angles-left"></i>
                        </button>
                    </div>

                    <!-- Quick Actions -->
                    ${quickActions && quickActions.length > 0 ? `
                    <div class="sidebar__quick-actions">
                        ${quickActions.map(action => `
                            <button class="sidebar__quick-action" data-action="${action.action}" title="${action.label}">
                                <i class="${action.icon}"></i>
                                <span>${action.label}</span>
                            </button>
                        `).join('')}
                    </div>
                    ` : ''}

                    <!-- Navigation -->
                    <nav class="sidebar__nav">
                        <ul class="sidebar__menu" role="navigation">
                            ${this.renderNavItems(navigation)}
                        </ul>
                    </nav>

                    <!-- Footer -->
                    ${footer.showHelp ? `
                    <div class="sidebar__footer">
                        <a href="${footer.helpLink}" class="sidebar__help">
                            <div class="sidebar__help-icon">
                                <i class="fa-solid fa-circle-question"></i>
                            </div>
                            <div class="sidebar__help-content">
                                <span class="sidebar__help-text">${footer.helpText}</span>
                                <span class="sidebar__help-link">Centro de Ayuda</span>
                            </div>
                        </a>
                    </div>
                    ` : ''}
                </div>
            </aside>
        `;

        this.container.innerHTML = html;
    },

    /**
     * Renderiza los items de navegación recursivamente
     */
    renderNavItems(items, level = 0) {
        return items.map(item => {
            const isActive = this.state.activeItem === item.id;
            const hasChildren = item.children && item.children.length > 0;
            const isExpanded = this.state.expandedMenus.includes(item.id);
            const isParentActive = hasChildren && item.children.some(child =>
                this.state.activeItem === child.id
            );

            return `
                <li class="sidebar__menu-item ${hasChildren ? 'has-children' : ''} ${isExpanded ? 'is-expanded' : ''}" data-item="${item.id}">
                    ${hasChildren ? `
                        <button class="sidebar__menu-link ${isActive || isParentActive ? 'is-active' : ''}" 
                                data-toggle="${item.id}"
                                aria-expanded="${isExpanded}">
                            <span class="sidebar__menu-icon">
                                <i class="${item.icon}"></i>
                            </span>
                            <span class="sidebar__menu-text">${item.label}</span>
                            ${item.badge ? this.renderBadge(item.badge) : ''}
                            <i class="fa-solid fa-chevron-down sidebar__menu-arrow"></i>
                        </button>
                        <ul class="sidebar__submenu" role="menu">
                            ${this.renderNavItems(item.children, level + 1)}
                        </ul>
                    ` : `
                        <a href="${item.href}" class="sidebar__menu-link ${isActive ? 'is-active' : ''}">
                            ${item.icon ? `
                                <span class="sidebar__menu-icon">
                                    <i class="${item.icon}"></i>
                                </span>
                            ` : ''}
                            <span class="sidebar__menu-text">${item.label}</span>
                            ${item.badge ? this.renderBadge(item.badge) : ''}
                        </a>
                    `}
                </li>
            `;
        }).join('');
    },

    /**
     * Renderiza un badge
     */
    renderBadge(badge) {
        const typeClass = badge.type ? `sidebar__badge--${badge.type}` : '';
        return `<span class="sidebar__badge ${typeClass}">${badge.count}</span>`;
    },

    /**
     * Vincula los eventos
     */
    bindEvents() {
        // Collapse toggle
        const collapseBtn = document.getElementById('sidebar-collapse');
        if (collapseBtn) {
            collapseBtn.addEventListener('click', () => this.toggleCollapse());
        }

        // Overlay click (mobile)
        const overlay = document.getElementById('sidebar-overlay');
        if (overlay) {
            overlay.addEventListener('click', () => this.closeMobile());
        }

        // Submenu toggles
        document.querySelectorAll('[data-toggle]').forEach(btn => {
            btn.addEventListener('click', (e) => this.toggleSubmenu(e));
        });

        // Quick actions
        document.querySelectorAll('.sidebar__quick-action').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleQuickAction(e));
        });

        // Listen for header mobile toggle
        window.addEventListener('header:toggleMobile', (e) => {
            this.toggleMobile(e.detail.isOpen);
        });

        // Listen for theme changes
        window.addEventListener('theme:change', (e) => {
            const sidebar = document.getElementById('admin-sidebar');
            if (sidebar) {
                sidebar.dataset.theme = e.detail.theme;
            }
        });

        // Resize handler
        window.addEventListener('resize', () => this.handleResize());

        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    },

    /**
     * Toggle collapse state
     */
    toggleCollapse() {
        this.state.isCollapsed = !this.state.isCollapsed;
        const sidebar = document.getElementById('admin-sidebar');

        if (sidebar) {
            sidebar.classList.toggle('is-collapsed', this.state.isCollapsed);
        }

        // Save state
        localStorage.setItem('sidebar-collapsed', this.state.isCollapsed);

        // Dispatch event
        window.dispatchEvent(new CustomEvent('sidebar:collapse', {
            detail: { isCollapsed: this.state.isCollapsed }
        }));
    },

    /**
     * Toggle mobile state
     */
    toggleMobile(forceState = null) {
        this.state.isMobileOpen = forceState !== null ? forceState : !this.state.isMobileOpen;
        const sidebar = document.getElementById('admin-sidebar');

        if (sidebar) {
            sidebar.classList.toggle('is-mobile-open', this.state.isMobileOpen);
        }

        // Prevent body scroll when sidebar is open
        document.body.style.overflow = this.state.isMobileOpen ? 'hidden' : '';
    },

    /**
     * Close mobile sidebar
     */
    closeMobile() {
        this.toggleMobile(false);

        // Also notify header
        window.dispatchEvent(new CustomEvent('sidebar:closeMobile'));
    },

    /**
     * Toggle submenu
     */
    toggleSubmenu(e) {
        const btn = e.currentTarget;
        const itemId = btn.dataset.toggle;
        const menuItem = btn.closest('.sidebar__menu-item');

        const isExpanded = this.state.expandedMenus.includes(itemId);

        if (isExpanded) {
            this.state.expandedMenus = this.state.expandedMenus.filter(id => id !== itemId);
            menuItem.classList.remove('is-expanded');
            btn.setAttribute('aria-expanded', 'false');
        } else {
            this.state.expandedMenus.push(itemId);
            menuItem.classList.add('is-expanded');
            btn.setAttribute('aria-expanded', 'true');
        }
    },

    /**
     * Handle quick action
     */
    handleQuickAction(e) {
        const action = e.currentTarget.dataset.action;

        window.dispatchEvent(new CustomEvent('sidebar:quickAction', {
            detail: { action }
        }));
    },

    /**
     * Handle resize
     */
    handleResize() {
        if (window.innerWidth > 1024 && this.state.isMobileOpen) {
            this.closeMobile();
        }
    },

    /**
     * Handle keyboard navigation
     */
    handleKeyboard(e) {
        if (e.key === 'Escape' && this.state.isMobileOpen) {
            this.closeMobile();
        }
    },

    /**
     * Set active item
     * @param {string} itemId - ID del item a activar
     */
    setActive(itemId) {
        this.state.activeItem = itemId;

        // Remove current active
        document.querySelectorAll('.sidebar__menu-link.is-active').forEach(link => {
            link.classList.remove('is-active');
        });

        // Add new active
        const newActive = document.querySelector(`[data-item="${itemId}"] > .sidebar__menu-link`);
        if (newActive) {
            newActive.classList.add('is-active');
        }
    },

    /**
     * Update navigation dynamically
     * @param {Array} navigation - New navigation items
     */
    updateNavigation(navigation) {
        this.config.navigation = navigation;
        this.detectActiveItem();

        const menu = document.querySelector('.sidebar__menu');
        if (menu) {
            menu.innerHTML = this.renderNavItems(navigation);

            // Re-bind submenu toggles
            document.querySelectorAll('[data-toggle]').forEach(btn => {
                btn.addEventListener('click', (e) => this.toggleSubmenu(e));
            });
        }
    },

    /**
     * Update badge on a navigation item
     * @param {string} itemId - ID del item
     * @param {Object|null} badge - Badge data or null to remove
     */
    updateBadge(itemId, badge) {
        const item = document.querySelector(`[data-item="${itemId}"] > .sidebar__menu-link`);
        if (!item) return;

        const existingBadge = item.querySelector('.sidebar__badge');

        if (badge === null && existingBadge) {
            existingBadge.remove();
        } else if (badge) {
            const badgeHtml = this.renderBadge(badge);
            if (existingBadge) {
                existingBadge.outerHTML = badgeHtml;
            } else {
                const arrow = item.querySelector('.sidebar__menu-arrow');
                if (arrow) {
                    arrow.insertAdjacentHTML('beforebegin', badgeHtml);
                } else {
                    item.insertAdjacentHTML('beforeend', badgeHtml);
                }
            }
        }
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SideBar;
}
